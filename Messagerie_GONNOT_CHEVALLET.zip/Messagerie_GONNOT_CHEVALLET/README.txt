Pour compiler:
- installer sodium si ce n'est pas déjà fait (voir ci-dessous)
- serveur: gcc server.c -lsodium
- client: gcc client.c -lsodium

Application prévue pour fonctionner avec une interface en console
(deux consoles séparées pour le serveur et le client respectivement)

Installer sodium:
- Aller sur https://libsodium.gitbook.io/doc/installation
- Telecharger la dernière version stable (nous avons utilisé: libsodium-1.0.17-stable.tar.gz)
- Dans le dossier "libsodium-stable", lancer les trois commandes séparément
    ./configure
    make && make check
    sudo make install