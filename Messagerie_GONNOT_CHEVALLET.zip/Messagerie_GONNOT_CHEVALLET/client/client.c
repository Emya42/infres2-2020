#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sodium.h>
#include <time.h>

#include <sys/types.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <string.h>

#include "../tools.c"

#define PORT 8080
#define SERVER_ADDRESS "127.0.0.1"
#define MAX_TEXT_LENTH 100


void chat(int socket, unsigned char* key) {

	Message message;

	while(1) {

		// write to server
		printf("Client: ");
		message.value = calloc(MAX_TEXT_LENTH, sizeof(char));
		fgets(message.value, MAX_TEXT_LENTH, stdin);
		message.length = strlen(message.value);
		sendCryptedMessage(socket, message, key);
		free(message.value);

		// wait for server to reply
		message = readCryptedMessage(socket, key);
		printf("Server: %s\n", message.value);
		free(message.value);
	}
}

unsigned char* getServerHash() {
	// simulate getting the hash, that was alredy stored, of the server who is challegend
	char password [] = "azerty";
	char salt [] = "123456";
	char password_salt [strlen(password)+strlen(salt)+1];
	password_salt[0] = 0;
	strcat(password_salt, password);
	strcat(password_salt, salt);
	unsigned char* password_hash = calloc(crypto_hash_sha256_BYTES, sizeof(char));
	crypto_hash_sha256(password_hash, password_salt, strlen(password_salt));
	return password_hash;
}

int main(int argc, char *argv[])
{
	int socket_desc;
	struct sockaddr_in server;

	printf("Initialising sodium... ");
	if(sodium_init() == -1) {
		perror("Failed\n");
		exit(0);
	} else {
		printf("OK\n");
	}

	printf("Creating socket... ");
	socket_desc = socket(AF_INET, SOCK_STREAM, 0);
	if (socket_desc == -1) {
		printf("Failed\n");
		exit(0);
	} else {
		printf("OK\n");
	}

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
	server.sin_port = htons(PORT);

	printf("Connecting to the server... "); 
	if (connect(socket_desc, (struct sockaddr *)&server, sizeof(server)) == -1) {
        printf("Failed\n"); 
        exit(0); 
    } else {
		printf("OK\n");
	}

	// TODO : Diffie-Hellman
	// receive key is unsecure
	printf("Initializing secure connection... "); 
	unsigned char* key;
	key = readKey(socket_desc);
	printf("OK\n");

	// simulate user entering his password
	char password [] = "azerty";
	printf("Your password: %s\n", password);

	// simulate getting the salt
	char salt [] = "123456";
	
	printf("Authenticating to server... "); 
	if (auth_answer(socket_desc, key, password, salt) == -1) {
        printf("Failed\n"); 
        exit(0); 
    } else {
		printf("OK\n");
	}

	unsigned char* server_hash = getServerHash();
	printf("Authentication of server... ");
	if (auth_challenge(socket_desc, key, server_hash) == -1) { 
        printf("Failed\n"); 
        exit(0); 
    } else {
		printf("OK\n"); 
	}
	free(server_hash);


	printf("--------------------------------------\n"); 
	

    // chat between client and server 
    chat(socket_desc, key); 

	// chat finished, closing
	free(key);
    close(socket_desc); 

	return 0;
}	