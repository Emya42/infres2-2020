#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <sodium.h>
#include <time.h>

#include <sys/types.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <string.h> 

#include "../tools.c"

#define PORT 8080
#define MAX_PENDING_CONNECTION 5
#define MAX_TEXT_LENTH 100



void chat(int socket, unsigned char* key) {

	Message message;

	while(1) {
		
		// wait for clientto reply
		message = readCryptedMessage(socket, key);
		printf("Client: %s\n", message.value);
		free(message.value);

		// write to client
		printf("Server: ");
		message.value = calloc(MAX_TEXT_LENTH, sizeof(char));
		fgets(message.value, MAX_TEXT_LENTH, stdin);
		message.length = strlen(message.value);
		sendCryptedMessage(socket, message, key);
		free(message.value);
	}
}

unsigned char* getClientHash() {
	// simulate getting the hash, that was alredy stored, of the client who is challegend
	char password [] = "azerty";
	char salt [] = "123456";
	char password_salt [strlen(password)+strlen(salt)+1];
	password_salt[0] = 0;
	strcat(password_salt, password);
	strcat(password_salt, salt);
	unsigned char* password_hash = calloc(crypto_hash_sha256_BYTES, sizeof(char));
	crypto_hash_sha256(password_hash, password_salt, strlen(password_salt));
	return password_hash;
}


int main(int argc , char *argv[])
{
	int socket_desc, client_sock, client_len;
	struct sockaddr_in server , client;

	printf("Initialising sodium... ");
	if(sodium_init() == -1) {
		perror("Failed\n");
		exit(0);
	} else {
		printf("OK\n");
	}

	printf("Creating socket... ");
	socket_desc = socket(AF_INET, SOCK_STREAM, 0);
	if (socket_desc == -1) {
		printf("failed\n");
		exit(0);
	} else {
		printf("OK\n");
	}

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(PORT);

	printf("Socket binding... ");
	if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) == -1) {
		perror("Failed\n");
		exit(0);
	} else {
		printf("OK\n");
	}

	printf("Server listening... ");
	if (listen(socket_desc, MAX_PENDING_CONNECTION) == -1) { 
        printf("Failed\n"); 
        exit(0); 
    } else {
		printf("OK\n"); 
	}
    

	client_len = sizeof(client);

	while(1) {

		puts("Waiting for incoming connections...\n");

		printf("Server acccepting client... "); 
		client_sock = accept(socket_desc, (struct sockaddr *)&client, &client_len);
    	if (client_sock == -1) { 
        	printf("Failed\n"); 
        	exit(0); 
    	} else {
			printf("OK\n"); 
		}

		// TODO : Diffie-Hellman
		// sendKey is unsecure
		printf("Initializing secure connection... "); 
		unsigned char key[crypto_aead_aes256gcm_KEYBYTES];
		crypto_aead_aes256gcm_keygen(key);
		sendKey(client_sock, key);
		printf("OK\n");

		unsigned char* client_hash = getClientHash();
		printf("Authentication of client... ");
		if (auth_challenge(client_sock, key, client_hash) == -1) { 
        	printf("Failed\n"); 
        	exit(0); 
    	} else {
			printf("OK\n"); 
		}
		free(client_hash);

		// simulate user entering his password
		char password [] = "azerty";
		printf("Your password: %s\n", password);

		// simulate getting the salt
		char salt [] = "123456";

		printf("Authenticating to client... "); 
		if (auth_answer(client_sock, key, password, salt) == -1) {
        	printf("Failed\n"); 
        	exit(0); 
    	} else {
			printf("OK\n");
		}
		
  		printf("--------------------------------------\n");

    	// chat between client and server 
    	chat(client_sock, key);
  
    	// After chatting close the client socket 
    	close(client_sock); 
	}

	// server stopping
	close(socket_desc); 

	return 0;
}
