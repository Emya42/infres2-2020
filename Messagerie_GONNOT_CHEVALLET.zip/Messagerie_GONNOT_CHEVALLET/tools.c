#include <unistd.h>
#include <sodium.h>
#include <time.h>
#include <string.h>


typedef struct Message Message;
struct Message {
	char tag;
	unsigned char* value;
	int length; // nb of char (or bytes)
};

void sendMessage(int socket, Message message) {
	write(socket, &message.tag, sizeof(char));
	write(socket, &message.length, sizeof(int));
	write(socket, message.value, message.length);
}

// WARNING: 'message.value' to free afterwards
Message readMessage(int socket) {
	char tag;
	read(socket, &tag, sizeof(char));
	int value_len;
	read(socket, &value_len, sizeof(int));
	char* value = calloc(value_len, sizeof(char));
	read(socket, value, value_len);
	Message message;
	message.tag = tag;
	message.value = value;
	message.length = value_len;
	return message;
}

// TODO : Diffie-Hellman
void sendKey(int socket, unsigned char key[]) {
	Message message;
	message.tag = 'k';
	message.value = key;
	message.length = crypto_aead_aes256gcm_KEYBYTES;
    sendMessage(socket, message);
}

// TODO : Diffie-Hellman
// WARNING: 'key' to free afterwards
unsigned char* readKey(int socket) {
	Message message;
	message = readMessage(socket);
	unsigned char* key = calloc(message.length, sizeof(char));
	memcpy(key, message.value, message.length);
	return key;
}

void sendCryptedMessage(int socket, Message messageToSend, unsigned char* key) {
	Message message;
	unsigned char ciphertext[messageToSend.length + crypto_aead_aes256gcm_ABYTES];
	unsigned long long ciphertext_len;
	unsigned char nonce[crypto_aead_aes256gcm_NPUBBYTES];

	crypto_aead_aes256gcm_encrypt(ciphertext, &ciphertext_len, messageToSend.value, messageToSend.length, NULL, 0, NULL, nonce, key);

	message.tag = 's';
	message.value = nonce;
	message.length = crypto_aead_aes256gcm_NPUBBYTES;
	sendMessage(socket, message);

	message.tag = 't';
	message.value = ciphertext;
	message.length = ciphertext_len;
	sendMessage(socket, message);
}

// WARNING: 'decryptedMessage.value' to free afterwards
Message readCryptedMessage(int socket, unsigned char* key) {
	Message message;
	Message decryptedMessage;
	unsigned char* nonce;
	unsigned char* ciphertext;
	unsigned long long decryptedText_len;

	message = readMessage(socket);
	nonce = calloc(message.length, sizeof(char));
	memcpy(nonce, message.value, message.length);

	message = readMessage(socket);
	ciphertext = calloc(message.length, sizeof(char));
	memcpy(ciphertext, message.value, message.length);
	int ciphertext_len = message.length;

	decryptedMessage.value = calloc((ciphertext_len - crypto_aead_aes256gcm_ABYTES), sizeof(char));
	if ( ciphertext_len < crypto_aead_aes256gcm_ABYTES ||
            crypto_aead_aes256gcm_decrypt(decryptedMessage.value, &decryptedText_len, NULL, ciphertext, ciphertext_len, NULL, 0, nonce, key) != 0) {
            /* message forged! */
        }

	free(nonce);
	free(ciphertext);

	decryptedMessage.tag = message.tag;
	decryptedMessage.length = ciphertext_len - crypto_aead_aes256gcm_ABYTES;

	return decryptedMessage;
}


void RandomString(unsigned char *str, size_t n) {

    int i, longueurChaine = 0;
    char chaine[] = "abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890&[](){}/-_*";

    longueurChaine = strlen(chaine);
    srand(time(NULL));
    for(i=0; i < n; i++)
        {
            str[i] = chaine[rand()%longueurChaine];
        }
}

// WARNING: 'out' to free afterwards
unsigned char* calculateAnswer(unsigned char* hash_P1_random, int size_hash_P1_random) {
    int j;
    char Part1[21];
    char Part2[21];

    for(j=0;j<42;j++){
        if(j < 21){
            Part1[j] = hash_P1_random[j];
        }else{
            Part2[j-21] = hash_P1_random[j];
        }
    }

    unsigned char* out = calloc(crypto_hash_sha256_BYTES, sizeof(char));
    crypto_hash_sha256_state state;
    crypto_hash_sha256_init(&state);
    crypto_hash_sha256_update(&state, Part1, 21);
    crypto_hash_sha256_update(&state, Part2, 21);
    crypto_hash_sha256_final(&state, out);

	return out;
}


int auth_answer(int socket, unsigned char* key, char* password, char* salt) {
	
	// determine hashed password
	char password_salt [strlen(password)+strlen(salt)+1];
	password_salt[0] = 0;
	strcat(password_salt, password);
	strcat(password_salt, salt);
    
	unsigned char password_hash[crypto_hash_sha256_BYTES];
	crypto_hash_sha256(password_hash, password_salt, strlen(password_salt));

	// recive random
	Message message;
	message = readCryptedMessage(socket, key);
	unsigned char* random = message.value;
	int random_size = message.length;

	// determine answer
	unsigned char password_hash_random [crypto_hash_sha256_BYTES+random_size];
	password_hash_random[0] = 0;
	strncat(password_hash_random, password_hash, crypto_hash_sha256_BYTES);
	strncat(password_hash_random, random, random_size);
	free(random);

	unsigned char* answer = calculateAnswer(password_hash_random, (crypto_hash_sha256_BYTES + random_size));

	// send answer
	message.value = answer;
	message.length = crypto_hash_sha256_BYTES;
	sendCryptedMessage(socket, message, key);
	free(answer);

	// recive result
	message = readCryptedMessage(socket, key);
	return atoi(message.value);
}


int auth_challenge(int socket, unsigned char* key, unsigned char* password_hash) {

	// generate random
	int random_size = 10;
	unsigned char random [random_size];
	RandomString(random, random_size);

	// send random
	Message message;
	message.tag = 'r';
	message.value = random;
	message.length = random_size;
	sendCryptedMessage(socket, message, key);

	// determine expected answer
	unsigned char password_hash_random [crypto_hash_sha256_BYTES+random_size];
	password_hash_random[0] = 0;
	strncat(password_hash_random, password_hash, crypto_hash_sha256_BYTES);
	strncat(password_hash_random, random, random_size);

	unsigned char* expected_answer = calculateAnswer(password_hash_random, (crypto_hash_sha256_BYTES + random_size));

	// recive answer
	message = readCryptedMessage(socket, key);
	unsigned char* answer = message.value;

	// determine result
	int result;
	if(strncmp(answer, expected_answer, crypto_hash_sha256_BYTES) == 0) {
		result = 0;
	} else {
		result = -1;
	}
	free(answer);
	free(expected_answer);

	// send result
	sprintf(message.value, "%d", result);
	message.length = sizeof(int);
	sendCryptedMessage(socket, message, key);

	return result;
}



















        
           














































